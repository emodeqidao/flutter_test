import 'package:flutter/material.dart';
import 'package:fluttertest/page/CarPage.dart';
import 'package:fluttertest/page/HomePage.dart';
import 'package:fluttertest/page/MinePage.dart';

void main() {
  runApp(SXMyApp());
}


class SXMyApp extends StatefulWidget {
  const SXMyApp({Key key}) : super(key: key);

  @override
  _SXMyAppState createState() => _SXMyAppState();
}

class _SXMyAppState extends State<SXMyApp> {
  List<BottomNavigationBarItem> bottomNavItems;
  List<Widget> pages;
  int currentIndex = 0;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    print('sxmyapp init state');
    bottomNavItems = [
      BottomNavigationBarItem(
        backgroundColor: Colors.blue,
        icon: Icon(Icons.home),
        label: "首页",
      ),
      BottomNavigationBarItem(
        backgroundColor: Colors.amber,
        icon: Icon(Icons.shopping_cart),
        label: "购物车",
      ),
      BottomNavigationBarItem(
        backgroundColor: Colors.red,
        icon: Icon(Icons.person),
        label: "个人中心",
      ),
    ];

    pages = [HomePage(), CarPage(), MinePage()];
  }



  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          items: bottomNavItems,
          currentIndex: currentIndex,
          onTap: (v) {
            setState(() {
              currentIndex = v;
            });
          },
        ),
        body: pages[currentIndex] ,
      ),
    );
  }
}
